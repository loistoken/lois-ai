<?php

extract( $atts );
	
?>
<div class="one-ib-circ-item">

	<?php $this->get_the_icon(); ?>
	
	<div class="one-ib-circ-cnt">

		<?php $this->get_title(); ?>
		<?php $this->get_content() ?>

	</div><!-- /.one-ib-circ-cnt -->

</div><!-- /.one-ib-circ-item -->
